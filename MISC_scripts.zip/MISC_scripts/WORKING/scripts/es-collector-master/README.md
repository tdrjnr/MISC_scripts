# es-collector

Sometimes we are not able to login to the systems of customers, we need a very
simple script to teach the customers collecting the useful information for us
to investigate the system problems.
