from .ifconfig import Ifcfg, Interface

__title__ = 'ifparser'
__version__ = '0.7.0'
__author__ = 'Sanket Sudake'

__all__ = ['Ifcfg', 'Interface']
