

**Documentation:** http://sy.afajl.com

**Source:** http://github.com/afajl/sy

